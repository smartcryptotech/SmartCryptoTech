Development moved to https://gitlab.com/blacknet-ninja

https://smartcryptotech.org/ aims to continue on SmartCryptoTech chain.
